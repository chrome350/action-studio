var RibbonsEffect = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    prepareRibbonSource: () => prepareRibbonSource,
    renderRibbonStretch: () => renderRibbonStretch,
    ribbonPixels: () => ribbonPixels
  });

  // source/ribbon-stretch.js
  function nearestRibbonCoordinate(values, value) {
    let low = 0, high = values.length;
    while (low < high) {
      const middle = low + high >>> 1;
      if (values[middle] < value) low = middle + 1;
      else high = middle;
    }
    if (!low) return values[0];
    if (low === values.length) return values[low - 1];
    return value - values[low - 1] <= values[low] - value ? values[low - 1] : values[low];
  }
  function ribbonPixels(data, width, height, length = 75, capture = 8, bend = 30, direction = "auto", mask = null) {
    const out = new Uint8ClampedArray(data);
    if (!mask || !length || !mask.some((v) => v)) return out;
    const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
    const smooth = (v) => {
      v = clamp(v, 0, 1);
      return v * v * (3 - 2 * v);
    };
    const distance = new Float32Array(width * height);
    for (let p = 0; p < distance.length; p++) distance[p] = mask[p] > 8 ? width + height : 0;
    for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
      const p = y * width + x;
      if (distance[p]) distance[p] = Math.min(distance[p], x ? distance[p - 1] + 1 : 1, y ? distance[p - width] + 1 : 1);
    }
    for (let y = height - 1; y >= 0; y--) for (let x = width - 1; x >= 0; x--) {
      const p = y * width + x;
      if (distance[p]) distance[p] = Math.min(distance[p], x < width - 1 ? distance[p + 1] + 1 : 1, y < height - 1 ? distance[p + width] + 1 : 1);
    }
    const reach = Math.max(1, width * clamp(length, 0, 100) / 100);
    const band = Math.max(1, capture * width / 600);
    const black = (x, y) => {
      const i = (y * width + x) * 4;
      return Math.max(data[i], data[i + 1], data[i + 2]) <= 2;
    };
    let left = 0, right = width - 1, topEdge = 0, bottomEdge = height - 1;
    while (left < right && Array.from({ length: height }, (_, y) => black(left, y)).every(Boolean)) left++;
    while (right > left && Array.from({ length: height }, (_, y) => black(right, y)).every(Boolean)) right--;
    while (topEdge < bottomEdge && Array.from({ length: width }, (_, x) => black(x, topEdge)).every(Boolean)) topEdge++;
    while (bottomEdge > topEdge && Array.from({ length: width }, (_, x) => black(x, bottomEdge)).every(Boolean)) bottomEdge--;
    const nonblackColumn = (x) => {
      let n = 0;
      for (let y = topEdge; y <= bottomEdge; y++) n += !black(x, y);
      return n / Math.max(1, bottomEdge - topEdge + 1);
    };
    if (right - left < width * 0.5 || bottomEdge - topEdge < height * 0.5 || nonblackColumn(left) < 0.85 || nonblackColumn(right) < 0.85) {
      left = 0;
      right = width - 1;
      topEdge = 0;
      bottomEdge = height - 1;
    }
    const median = (a) => a.sort((a2, b) => a2 - b)[Math.floor(a.length / 2)];
    const channels = [[], [], []];
    for (let y = topEdge; y <= bottomEdge; y++) for (const x of [left, right]) for (let c = 0; c < 3; c++) channels[c].push(data[(y * width + x) * 4 + c]);
    const bg = channels.map(median);
    const foreground = new Float32Array(width * height);
    for (let y = 0; y < height; y++) {
      const edges = [left, right].map((x) => [0, 1, 2].map((c) => {
        const values = [];
        for (let dy = -3; dy <= 3; dy++) {
          const yy = clamp(y + dy, topEdge, bottomEdge);
          values.push(data[(yy * width + x) * 4 + c]);
        }
        return median(values);
      }));
      const consistent = Math.max(...edges[0].map((v, c) => Math.abs(v - edges[1][c]))) < 60;
      for (let x = 0; x < width; x++) {
        const p = y * width + x, i = p * 4, t = clamp((x - left) / Math.max(1, right - left), 0, 1);
        const r = consistent ? edges[0][0] * (1 - t) + edges[1][0] * t : bg[0];
        const g = consistent ? edges[0][1] * (1 - t) + edges[1][1] * t : bg[1];
        const b = consistent ? edges[0][2] * (1 - t) + edges[1][2] * t : bg[2];
        const delta = Math.max(Math.abs(data[i] - r), Math.abs(data[i + 1] - g), Math.abs(data[i + 2] - b));
        foreground[p] = x < left || x > right || y < topEdge || y > bottomEdge ? 0 : smooth((delta - 4) / 18) * (data[i + 3] / 255);
      }
    }
    const visited = new Uint8Array(width * height), surfaces = [];
    for (let seed = 0; seed < mask.length; seed++) {
      if (visited[seed] || mask[seed] <= 8) continue;
      const queue = [seed];
      visited[seed] = 1;
      const rows = /* @__PURE__ */ new Map();
      for (let q = 0; q < queue.length; q++) {
        const p = queue[q], x = p % width, y = Math.floor(p / width), u = x;
        if (foreground[p] > 0.35) {
          const row = rows.get(y) || [];
          row.push(u);
          rows.set(y, row);
        }
        for (const n of [x > 0 ? p - 1 : -1, x < width - 1 ? p + 1 : -1, y > 0 ? p - width : -1, y < height - 1 ? p + width : -1]) if (n >= 0 && !visited[n] && mask[n] > 8) {
          visited[n] = 1;
          queue.push(n);
        }
      }
      let sumX = 0, points = 0;
      for (const xs of rows.values()) for (const x of xs) {
        sumX += x;
        points++;
      }
      const flip = direction === "right" || direction === "auto" && points > 0 && sumX / points > (width - 1) / 2;
      if (flip) for (const [y, xs] of rows) rows.set(y, xs.map((x) => width - 1 - x));
      const ys = [...rows.keys()].sort((a, b) => a - b);
      if (ys.length < 2) continue;
      const top = ys[0], bottom = ys[ys.length - 1], raw = /* @__PURE__ */ new Map();
      for (const y of ys) {
        const xs = rows.get(y).sort((a, b) => a - b), edge = xs[Math.floor((xs.length - 1) * 0.08)], inner = xs[xs.length - 1];
        raw.set(y, [edge + Math.min(inner - edge, Math.max(2, band)), Math.max(1, Math.min(inner - edge, Math.max(2, band)))]);
      }
      const filled = [];
      let j = 0;
      for (let y = top; y <= bottom; y++) {
        while (j < ys.length - 2 && ys[j + 1] < y) j++;
        const ya = ys[j], yb = ys[Math.min(j + 1, ys.length - 1)], t = yb === ya ? 0 : clamp((y - ya) / (yb - ya), 0, 1), pa = raw.get(ya), pb = raw.get(yb);
        filled.push([pa[0] * (1 - t) + pb[0] * t, pa[1] * (1 - t) + pb[1] * t]);
      }
      const radius = Math.max(2, Math.round(height * 0.012)), fitted = [];
      for (let i = 0; i < filled.length; i++) {
        let weight = 0, a = 0, b = 0;
        for (let k = -radius; k <= radius; k++) {
          const w = radius + 1 - Math.abs(k), p = filled[clamp(i + k, 0, filled.length - 1)];
          a += p[0] * w;
          b += p[1] * w;
          weight += w;
        }
        fitted.push([a / weight, b / weight]);
      }
      surfaces.push({ top, bottom, fitted, ys, rows, flip });
    }
    const sample = (x, y) => {
      x = clamp(x, 0, width - 1);
      y = clamp(y, 0, height - 1);
      const x0 = Math.floor(x), y0 = Math.floor(y), fx = x - x0, fy = y - y0;
      let red = 0, green = 0, blue = 0, alpha = 0;
      for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) {
        const i = (Math.min(height - 1, y0 + dy) * width + Math.min(width - 1, x0 + dx)) * 4;
        const w = (dx ? fx : 1 - fx) * (dy ? fy : 1 - fy) * data[i + 3] / 255;
        alpha += w;
        red += data[i] * w;
        green += data[i + 1] * w;
        blue += data[i + 2] * w;
      }
      return [alpha ? red / alpha : 0, alpha ? green / alpha : 0, alpha ? blue / alpha : 0, alpha];
    };
    for (const surface of surfaces) {
      let profile = function(y) {
        const v = clamp(y - top, 0, fitted.length - 1), a = Math.floor(v), b = Math.min(fitted.length - 1, a + 1), t = v - a;
        return [fitted[a][0] * (1 - t) + fitted[b][0] * t, fitted[a][1] * (1 - t) + fitted[b][1] * t, 1];
      };
      const { top, bottom, fitted, flip } = surface;
      const pixel = (u, y) => y * width + (flip ? width - 1 - u : u);
      const center = (top + bottom) / 2, span = Math.max(2, bottom - top);
      let count = 0, sumU = 0, sumY = 0, sumUU = 0, sumUY = 0;
      for (const [y, xs] of surface.rows) for (const u of xs) {
        count++;
        sumU += u;
        sumY += y;
        sumUU += u * u;
        sumUY += u * y;
      }
      const heading = clamp(-(sumUY - sumU * sumY / count) / Math.max(1, sumUU - sumU * sumU / count), -0.65, 0.65);
      let minimumEdge = Infinity, maximumEdge = -Infinity;
      for (const row of fitted) {
        minimumEdge = Math.min(minimumEdge, row[0] - row[1]);
        maximumEdge = Math.max(maximumEdge, row[0]);
      }
      const firstU = Math.max(0, Math.floor(minimumEdge - reach) - 1), lastU = Math.min(width - 1, Math.ceil(maximumEdge) + 1);
      const turnBound = bend / 100;
      const extent = span / 2 * (1 + 0.22 * turnBound) + turnBound * (Math.abs(heading) * width * 0.14 + span * 0.185);
      const bounded = bend >= 0 && bend <= 100;
      const firstY = bounded ? Math.max(0, Math.floor(center - extent) - 1) : 0;
      const lastY = bounded ? Math.min(height - 1, Math.ceil(center + extent) + 1) : height - 1;
      for (let y = firstY; y <= lastY; y++) for (let u = firstU; u <= lastU; u++) {
        const dest = pixel(u, y), selected = mask[dest] / 255 * smooth(distance[dest] / Math.max(1, width * 0.012));
        if (foreground[dest] >= 1 && !selected) continue;
        let sy = y, pr = null, d = 0;
        for (let iteration = 0; iteration < 8; iteration++) {
          pr = profile(sy);
          d = pr[0] - u;
          if (d <= 0) break;
          const q = d / Math.max(1, width * 0.14), ease = 1 - Math.exp(-q * q);
          const turn = bend / 100;
          const breadth = 1 + turn * (-0.3 * Math.exp(-(((q - 0.85) / 0.55) ** 2)) + 0.22 * Math.exp(-(((q - 2) / 0.85) ** 2))) * ease;
          const drift = turn * (heading * width * 0.14 * (1 - Math.exp(-q)) * ease + span * 0.13 * Math.sin(q * 1.6) * Math.exp(-q * 0.65) * ease);
          const curl = turn * span * 0.055 * Math.sin((sy - top) / span * Math.PI * 2) * ease * Math.exp(-q * 0.4);
          const next = center + (y - center - drift - curl) / breadth;
          sy = sy * 0.2 + next * 0.8;
        }
        pr = profile(sy);
        if (sy < top || sy > bottom) continue;
        d = pr[0] - u;
        if (d <= 0 || d > reach + pr[1]) continue;
        const scale = pr[1] / Math.max(0.05, Math.min(1, length / 35));
        const sourceU = pr[0] - pr[1] * 0.85 * (1 - Math.exp(-d / (scale * 0.85)));
        const color = [0, 0, 0, 0], row0 = Math.floor(sy), fraction = sy - row0;
        for (let oy = 0; oy < 2; oy++) {
          const ry = clamp(row0 + oy, top, bottom);
          let validRow = ry;
          if (!surface.rows.has(validRow)) validRow = nearestRibbonCoordinate(surface.ys, ry);
          const xs = surface.rows.get(validRow);
          const nearest = nearestRibbonCoordinate(xs, sourceU);
          const su = Math.abs(nearest - sourceU) > 1 ? nearest : sourceU;
          const c = sample(flip ? width - 1 - su : su, validRow), w = oy ? fraction : 1 - fraction;
          for (let ch = 0; ch < 4; ch++) color[ch] += c[ch] * w;
        }
        const transition = smooth(d / Math.max(1, pr[1] * 0.6));
        const endFade = smooth((reach + pr[1] - d) / Math.max(2, width * 0.025));
        const rim = smooth((sy - top) / 2) * smooth((bottom - sy) / 2);
        const bright = Math.max(color[0], color[1], color[2]) / 255;
        const below = sample(flip ? width - 1 - sourceU : sourceU, clamp(sy + height / 300, 0, height - 1));
        const above = sample(flip ? width - 1 - sourceU : sourceU, clamp(sy - height / 300, 0, height - 1));
        const contrast = Math.max(Math.abs(color[0] - (above[0] + below[0]) * 0.5), Math.abs(color[1] - (above[1] + below[1]) * 0.5), Math.abs(color[2] - (above[2] + below[2]) * 0.5)) / 255;
        const highlight = smooth((bright - 0.4) / 0.45) * smooth(contrast / 0.12);
        const progression = smooth(u / Math.max(1, pr[0] * 0.82));
        const edgeFade = 0.025 + 0.975 * Math.pow(progression, 1 - 0.65 * highlight);
        const coverage = (1 - foreground[dest] + foreground[dest] * selected) * rim * transition * endFade * edgeFade;
        if (!coverage) continue;
        const foldLight = 1 + 0.1 * bend / 100 * Math.sin(sy / height * Math.PI * 8.4) * Math.pow(1 - Math.exp(-d / (width * 0.12)), 2);
        const luminance = 0.2126 * color[0] + 0.7152 * color[1] + 0.0722 * color[2];
        const saturation = 1 + 0.12 * transition;
        for (let c = 0; c < 3; c++) color[c] = clamp(luminance + (color[c] - luminance) * saturation, 0, 255);
        const i = dest * 4, sa = color[3] * coverage, da = data[i + 3] / 255, oa = sa + da * (1 - sa);
        for (let c = 0; c < 3; c++) out[i + c] = oa ? (color[c] * foldLight * sa + data[i + c] * da * (1 - sa)) / oa : 0;
        out[i + 3] = oa * 255;
      }
    }
    return out;
  }
  function prepareRibbonSource(data, width, height, mask, source = null, zoom = 100, brightness = 100) {
    const isVideo = source?.tagName === "VIDEO";
    const scale = isVideo ? 1 : 2, w = width * scale, h = height * scale;
    const high = document.createElement("canvas");
    high.width = w;
    high.height = h;
    const ctx = high.getContext("2d");
    if (source) {
      ctx.fillStyle = "#000";
      ctx.fillRect(0, 0, w, h);
    }
    if (source) {
      ctx.save();
      ctx.translate(w / 2, h / 2);
      ctx.scale(zoom / 100, zoom / 100);
      ctx.translate(-w / 2, -h / 2);
      const fit = Math.max(w / source.naturalWidth, h / source.naturalHeight), sw = source.naturalWidth * fit, sh = source.naturalHeight * fit;
      ctx.drawImage(source, (w - sw) / 2, (h - sh) / 2, sw, sh);
      ctx.restore();
    } else {
      const small = document.createElement("canvas");
      small.width = width;
      small.height = height;
      small.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(data), width, height), 0, 0);
      ctx.drawImage(small, 0, 0, w, h);
    }
    const hi = ctx.getImageData(0, 0, w, h);
    if (source && brightness !== 100) for (let i = 0; i < hi.data.length; i += 4) for (let c = 0; c < 3; c++) hi.data[i + c] *= brightness / 100;
    const hm = new Uint8ClampedArray(w * h);
    if (mask) for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) hm[y * w + x] = mask[Math.floor(y / scale) * width + Math.floor(x / scale)];
    return { width: w, height: h, rgba: hi.data, mask: hm };
  }
  function renderRibbonStretch(data, width, height, length, capture, bend, direction, mask, source = null, zoom = 100, brightness = 100) {
    const isVideo = source?.tagName === "VIDEO";
    const key = [source, mask, width, height, length, capture, bend, direction, zoom, brightness, isVideo ? source.currentTime : null];
    const cached = renderRibbonStretch.cache;
    if (source && cached && key.every((v, i) => v === cached.key[i])) return cached.canvas;
    const prepared = prepareRibbonSource(data, width, height, mask, source, zoom, brightness);
    const w = prepared.width, h = prepared.height, hi = { data: prepared.rgba }, hm = prepared.mask;
    const high = document.createElement("canvas");
    high.width = w;
    high.height = h;
    const ctx = high.getContext("2d");
    ctx.putImageData(new ImageData(ribbonPixels(hi.data, w, h, length, capture, bend, direction, hm), w, h), 0, 0);
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const preview = canvas.getContext("2d");
    preview.imageSmoothingEnabled = true;
    preview.imageSmoothingQuality = "high";
    preview.drawImage(high, 0, 0, width, height);
    canvas.highResolution = high;
    if (source) renderRibbonStretch.cache = { key, canvas };
    return canvas;
  }
  return __toCommonJS(stdin_exports);
})();
